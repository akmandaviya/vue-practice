<template>
    <div>
        <h2>Home Page</h2>
        <router-link to="/child">Child Page</router-link>
    </div>
</template>
<script setup>
</script>